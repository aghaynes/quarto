### R code from vignette source 'C:/Users/lbuetikofer/Stuff/latex/ub_latex_template/analysis.rnw'

###################################################
### code chunk number 1: Rsetup
###################################################

#path 
path<-here::here()


#github libraries
# install.packages("remotes")
remotes::install_github("CTU-Bern/accrualPlot")
library(accrualPlot)
remotes::install_github("CTU-Bern/btabler")
library(btabler)

#default setting
options(stringsAsFactors=FALSE)
Sys.setlocale("LC_TIME", "C")
format(Sys.time(), "%a %b %d %X %Y %Z")




###################################################
### code chunk number 2: bltable
###################################################

#using atable

library(atable)

mtcars<-datasets::mtcars
mtcars$gear<-factor(mtcars$gear)
mtcars$vs<-factor(mtcars$vs)
levels(mtcars$vs)<-c("V-shaped engine", "Straight engine")
Hmisc::label(mtcars$mpg)<-"Consumption [miles/gallon]" 
Hmisc::label(mtcars$qsec)<-"Quarter mile time (s)"
tab<-atable(mpg + hp+gear+qsec+cyl~vs, mtcars, format_to="Latex")
tab<-tab[,colnames(tab)!="stat"]

Hmisc::latex(tab, file="", title="", label="tab:mtcarsatable", 
	caption="mtcars analyzed by atable.",
	rowname=NULL,where="H")



###################################################
### code chunk number 3: bltable
###################################################

#printed via btable (an xtable wrapper)

tab2<-rbind(colnames(tab),tab)

btable(tab2,nfoot=0,nhead=1,caption="mtcars analyzed by atable and printed using btable.")



###################################################
### code chunk number 4: sessionInfo
###################################################
sessionInfo();


